import React from "react";
import { Radar } from "react-chartjs-2";
import { Chart, registerables } from "chart.js";

Chart.register(...registerables);

function L4ManagersChart({ tableData }) {
  const radarChartData = {
    labels: ["Project Key Count", "Repos Count", "LSE", "Unify", "non"], // X-axis labels
    datasets: Array.isArray(tableData) 
      ? tableData.map((row, index) => ({
          label: row["L4 Managers"], // Fixed field name
          data: [
            row["Project Key Count"],
            row["Repos Count"],
            row["LSE"],
            row["Unify"],
            row["non"],
          ],
          backgroundColor: `rgba(${Math.min(index * 50, 255)}, ${Math.max(255 - index * 30, 0)}, 132, 0.2)`, 
          borderColor: `rgba(${Math.min(index * 50, 255)}, ${Math.max(255 - index * 30, 0)}, 132, 1)`, 
          borderWidth: 2,
        })) 
      : [], // Ensures no errors if tableData is missing
  };

  return (
    <div>
      <h2>L4 Managers Overview</h2>
      <Radar data={radarChartData} />
    </div>
  );
}

export default L4ManagersChart;