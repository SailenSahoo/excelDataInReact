import React from 'react';
import { Line } from 'react-chartjs-2';
import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);
function PipelineByL6({ tableData }) {
  const chartData1 = {
    labels: tableData?.map((row) => row['L6 Managers1']),
    datasets: [
      {
        label: 'LSE Diff',
        data: tableData.map((row) => row['LSE Diff']),
        backgroundColor: 'rgba(54, 162, 235, 0.2)', // Light blue with opacity
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1,
        fill: 'origin', // Fill the area under the line
      },
      {
        label: 'Non-Unify/Non-LSE Diff',
        data: tableData.map((row) => row['Non-Unify/Non-LSE Diff']),
        backgroundColor: 'rgba(255, 99, 132, 0.2)', // Light red with opacity
        borderColor: 'rgba(255, 99, 132, 1)',
        borderWidth: 1,
        fill: 'origin', // Fill the area under the line
      },
      {
        label: 'Unify Diff',
        data: tableData.map((row) => row['Unify Diff']),
        backgroundColor: 'rgba(255, 206, 86, 0.2)', // Light yellow with opacity
        borderColor: 'rgba(255, 206, 86, 1)',
        borderWidth: 1,
        fill: 'origin', // Fill the area under the line
      },
    ],
  };
  const chartData2 = {
    labels: tableData?.map((row) => row['L6 Managers1']),
    datasets: [
      {
        label: 'LSE',
        data: tableData.map((row) => row['LSE - 10/03/24']),
        backgroundColor: 'rgba(54, 162, 235, 0.2)', // Light blue with opacity
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1,
        fill: 'origin', // Fill the area under the line
      },
      {
        label: 'Non-Unify/Non-LSE',
        data: tableData.map((row) => row['Non-Unify/Non-LSE - 10/03/24']),
        backgroundColor: 'rgba(255, 99, 132, 0.2)', // Light red with opacity
        borderColor: 'rgba(255, 99, 132, 1)',
        borderWidth: 1,
        fill: 'origin', // Fill the area under the line
      },
      {
        label: 'Unify',
        data: tableData.map((row) => row['Unify - 10/03/24']),
        backgroundColor: 'rgba(255, 206, 86, 0.2)', // Light yellow with opacity
        borderColor: 'rgba(255, 206, 86, 1)',
        borderWidth: 1,
        fill: 'origin', // Fill the area under the line
      },
    ],
  };
  const chartData3 = {
    labels: tableData?.map((row) => row['L6 Managers1']),
    datasets: [
      {
        label: 'LSE',
        data: tableData.map((row) => row['LSE - 01/20/25']),
        backgroundColor: 'rgba(54, 162, 235, 0.2)', // Light blue with opacity
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1,
        fill: 'origin', // Fill the area under the line
      },
      {
        label: 'Non-Unify/Non-LSE',
        data: tableData.map((row) => row['Non-Unify/Non-LSE - 01/20/25']),
        backgroundColor: 'rgba(255, 99, 132, 0.2)', // Light red with opacity
        borderColor: 'rgba(255, 99, 132, 1)',
        borderWidth: 1,
        fill: 'origin', // Fill the area under the line
      },
      {
        label: 'Unify',
        data: tableData.map((row) => row['Unify - 01/20/25']),
        backgroundColor: 'rgba(255, 206, 86, 0.2)', // Light yellow with opacity
        borderColor: 'rgba(255, 206, 86, 1)',
        borderWidth: 1,
        fill: 'origin', // Fill the area under the line
      },
    ],
  };
  const chartOptions = {
    legend: {
      position: 'bottom',
    },
    scales: {
      x: {
        title: {
          display: true,
          text: 'L6 Managers',
        },
      },
      y: {
        title: {
          display: true,
          text: 'Increase/Decrease in Repos',
        },
        //min: -10,
        //max: 20,
      },
    },
    plugins: {
      tooltip: {
        callbacks: {
          label: function (context) {
            let label = context.dataset.label || '';
            if (label) {
              label += ': ';
            }
            if (context.parsed.y !== null) {
              label += context.parsed.y;
            }
            return label;
          },
        },
      },
    },
  };
  return (
    <div>
      <h2>Pipeline by L6</h2>
      <h3>The difference between 10/03/24 and 01/20/25</h3>
      <Line 
        data={chartData1} 
        options={chartOptions} 
        width={800}  // Set the desired width
        height={300} // Set the desired height
      />
      <h3>Data as of 10/03/24</h3>
      <Line 
        data={chartData2} 
        options={chartOptions} 
        width={800}  // Set the desired width
        height={300} // Set the desired height
      />
      <h3>Data as of 01/20/25</h3>
      <Line 
        data={chartData3} 
        options={chartOptions} 
        width={800}  // Set the desired width
        height={300} // Set the desired height
      />
    </div>
  );
}
export default PipelineByL6;    
