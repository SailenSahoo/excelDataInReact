import React, { useCallback, useState, useEffect } from 'react';
import XLSXDataTable from './XLSXDataTable';
import LeftPane from './LeftPane';
import L6ManagersChart from './L6ManagersChart';
import L5ManagersChart from './L5ManagersChart'; // Import L5ManagersChart
import PipelineByL6 from "./pipelineByL6";
import L4ManagersChart from './L4ManagersChart';
import './App.css';
function App() {
  const [activeTab, setActiveTab] = useState('data');
  const [tableData, setTableData] = useState(); // Data for Sheet1 (L6 Managers)
  //const [l5TableData, setL5TableData] = useState(); // Data for Sheet2 (L5 Managers)
  const [selectedSheet, setSelectedSheet] = useState(0);
  
  const handleDataLoaded = useCallback((data, sheetIndex) => {
    if (sheetIndex === 0) {
      setTableData(data);
    }

  },);
  useEffect(() => {
  }, [tableData]);
  return (
    <div className="app-container">
      <LeftPane activeTab={activeTab} setActiveTab={setActiveTab} setSelectedSheet={setSelectedSheet} />
      <div className="app-content">
        {activeTab === 'data' && (
          <XLSXDataTable
            onDataLoaded={handleDataLoaded}
            selectedSheet={selectedSheet}
            activeTab={activeTab}
          />
        )}
        {activeTab === 'L6 Managers' && (
          <L6ManagersChart tableData={tableData} />
        )}
        {activeTab === 'L5 Managers' && (
          <L5ManagersChart tableData={tableData} /> 
        )}
        {activeTab === "pipeline" && ( 
          <PipelineByL6 
            tableData={tableData} 
          />
        )}
        {activeTab === "L4 Manager" && ( 
          <L4ManagersChart 
            tableData={tableData} 
          />
        )}
      </div>
    </div>
  );
}
export default App;