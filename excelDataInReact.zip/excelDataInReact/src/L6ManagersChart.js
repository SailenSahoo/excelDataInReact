// src/L6ManagersChart.js
import React from 'react';
import { Bar } from 'react-chartjs-2';
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

function L6ManagersChart({ tableData }) {
  const chartDataCSI = {
    labels: tableData.map((row) => row['L6 Managers']),
    datasets: [
      {
        label: 'CSI ID',
        data: tableData.map((row) => row['CSI ID']),
        backgroundColor: 'rgba(54, 162, 235, 0.6)',
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1,
      },
    ],
  };

  const chartDataProjectKey = {
    labels: tableData.map((row) => row['L6 Managers']),
    datasets: [
      {
        label: 'Project Count',
        data: tableData.map((row) => row['Project Count']),
        backgroundColor: 'rgba(255, 99, 132, 0.6)',
        borderColor: 'rgba(255, 99, 132, 1)',
        borderWidth: 1,
      },
    ],
  };

  const chartDataRepoName = {
    labels: tableData.map((row) => row['L6 Managers']),
    datasets: [
      {
        label: 'Repo Count',
        data: tableData.map((row) => row['Repo Count']),
        backgroundColor: 'rgba(255, 206, 86, 0.6)',
        borderColor: 'rgba(255, 206, 86, 1)',
        borderWidth: 1,
      },
    ],
  };

  return (
    <div>
      <h2>L6 Managers</h2>
      <Bar data={chartDataCSI} />
      <Bar data={chartDataProjectKey} />
      <Bar data={chartDataRepoName} />
    </div>
  );
}

export default L6ManagersChart;