// src/LeftPane.js
import React from 'react';
import './LeftPane.css';

function LeftPane({ activeTab, setActiveTab, setSelectedSheet }) {
  return (
    <div className="left-pane">
      <h2 className="left-pane-logo">Material Dashboard 2</h2>
      <ul className="left-pane-nav-list">
        <li
          className={`left-pane-nav-item ${
            activeTab === 'L6 Managers' ? 'left-pane-nav-item-active' : ''
          }`}
          onClick={() => {
            setActiveTab('L6 Managers');
            setSelectedSheet(0);
        }}
        >
          L6 Managers
        </li>
        <li
          className={`left-pane-nav-item ${
            activeTab === 'L5 Managers' ? 'left-pane-nav-item-active' : ''
          }`}
          onClick={() => {
            setActiveTab('L5 Managers');
            setSelectedSheet(0);
        }}
        >
          L5 Managers
        </li>
        <li
          className={`left-pane-nav-item ${
            activeTab === 'data' ? 'left-pane-nav-item-active' : ''
          }`}
          onClick={() => {
            setActiveTab('data');
            setSelectedSheet(0);
        }}
        >
          Data
        </li>
        <li
          className={`left-pane-nav-item ${
            activeTab === "pipeline" ? "left-pane-nav-item-active" : ""
          }`}
          onClick={() => {
            setActiveTab("pipeline");
            setSelectedSheet(0);
          }}
        >
          Pipelines : L6
        </li>
        <li
          className={`left-pane-nav-item ${
            activeTab === "L4 Managers" ? "left-pane-nav-item-active" : ""
          }`}
          onClick={() => {
            setActiveTab("L4 Managers");
            setSelectedSheet(0);
          }}
        >
          Mike Sahoo
        </li>
      </ul>
    </div>
  );
}

export default LeftPane;