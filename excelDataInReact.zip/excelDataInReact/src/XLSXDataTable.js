import React, { useState, useEffect, useCallback } from 'react';
import * as XLSX from 'xlsx';
function XLSXDataTable({ onDataLoaded, selectedSheet }) {
  const [data, setData] = useState([]);
  const [fileError, setFileError] = useState(null);
  const [visibleColumns, setVisibleColumns] = useState(['L6 Managers', 'CSI ID', 'Project Count', 'Repo Count']);
  const fetchData = useCallback(async () => {
    setFileError(null);
    try {
      const response = await fetch('/data/mydata.xlsx');
      const arrayBuffer = await response.arrayBuffer();
      const workbook = XLSX.read(arrayBuffer, { type: 'array' });
      const sheetName = workbook.SheetNames[selectedSheet];
      if (!sheetName) {
        setFileError('Sheet not found');  
        return;
      }
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
      if (!jsonData || jsonData.length === 0) {
        setFileError('Sheet is empty');
        return;
      }
      const headers = jsonData[0];
      const rows = jsonData.slice(1);
      const formattedData = rows.map((row) =>
        headers.reduce((obj, header, index) => {
          obj[header] = row[index];
          return obj;
        }, {})
      );
      setData(formattedData);
      onDataLoaded(formattedData, selectedSheet);
    } catch (error) {
      console.error('Error fetching or parsing Excel:', error);
      setFileError('Error processing file');
    }
  }, [onDataLoaded, selectedSheet]);

  const handleButtonClick = (columnsToShow = []) => {
    setVisibleColumns(columnsToShow || []);
  };

  useEffect(() => {
    fetchData();
  }, [fetchData, selectedSheet]); // Correct useEffect with dependencies
  useEffect(() => {
    setVisibleColumns(['L6 Managers', 'CSI ID', 'Project Count', 'Repo Count']);
  }, []);

  return (
    <div>
      {fileError && <p style={{ color: 'red' }}>{fileError}</p>}

      <button onClick={() => handleButtonClick(['L6 Managers', 'CSI ID', 'Project Count', 'Repo Count'])}>
        Show L6 Manager Data
      </button>
      <button onClick={() => handleButtonClick(['L5 Managers', 'CSI ID - L5', 'Project Count - L5', 'Repo Count - L5'])}>
        Show L5 Manager Data
      </button>
      <button onClick={() => handleButtonClick(['L6 Managers1', 'LSE - 10/03/24', 'Non-Unify/Non-LSE - 10/03/24', 'Unify - 10/03/24'])}>
        Show Pipeline Data
      </button>
      {/* <button onClick={() => handleButtonClick()}>Show All Columns</button> */}

      {data && data.length > 0 && (
        <table>
          <thead>
            {/* <tr>
              {Object.keys(data[0]).map((header) => (
                <th key={header}>{header}</th>
              ))}
            </tr> */}
            <tr>
              {Object.keys(data[0])
                .filter(header => !visibleColumns || visibleColumns.length === 0 || visibleColumns.includes(header))
                .map(header => (
                  <th key={header}>{header}</th>
                ))}
            </tr>
          </thead>
          <tbody>
            {data.map((row, index) => (
              // <tr key={index}>
              //   {Object.values(row).map((value, index2) => (
              //     <td key={index2}>{value}</td>
              //   ))}
              // </tr>
              <tr key={index}>
                {Object.keys(row)
                  .filter(header => !visibleColumns || visibleColumns.length === 0 || visibleColumns.includes(header))
                  .map(header => (
                    <td key={header}>{row[header]}</td>
                  ))}
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
export default XLSXDataTable;
