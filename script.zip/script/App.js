// App.js
import React from "react";
import Dashboard from "./dashboard.js";
import "./App.css";

function App() {
  return (
    <div className="App">
      {/* <h1 className="text-center text-2xl font-bold my-4">Project Dashboard</h1> */}
      <h1 className="dashboard-title">Project Dashboard</h1>
      <Dashboard />
    </div>
  );
}

export default App;
